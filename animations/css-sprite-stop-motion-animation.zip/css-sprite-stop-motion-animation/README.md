# CSS Sprite Stop Motion Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/ChrisBup/pen/QWQaRvo](https://codepen.io/ChrisBup/pen/QWQaRvo).

